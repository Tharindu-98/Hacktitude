## Hacktitude.io - Getting Started

>>DISCLAIMER: Please note that this project is created only for the purpose of Hacktitude.io and do NOT represent best practices of software development. The project contains purposefully placed errors, bad design practices, bad code quality and security malpractices.

Please visit [Hacktitude Challenge Guide](https://devgrade-dev.github.io/hacktitude.github.io/) to learn more on getting started.
