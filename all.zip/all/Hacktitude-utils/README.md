Hacktitude-utils
